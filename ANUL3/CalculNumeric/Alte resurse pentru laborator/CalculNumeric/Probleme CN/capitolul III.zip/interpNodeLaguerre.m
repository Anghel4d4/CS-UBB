
    %%
    % Calculeaza in ni puncte echidistante poliniomul de interpolare al functiei f 
    % in n noduri ale polinomului Laguarre

function [yi,xi] = interpNodeLaguerre(f,n,ni)
    x = rootsLaguerre(n);
    y = f(x);
    xi = linspace(x(1),x(length(x)),ni);
    yi = interpolare(x,y,xi);
end



    %%
    % Din tabelul de polinoame ortogonale: 
    %     
    % 
    % 
    % * alphaK = 2*k + alpha + 1
    % * betaK = gamma(1+alpha) k == 0 sau  k(k+alpha)  k >  0 
    % * interval pentru Laguerre: [0,inf)

    
function x = rootsLaguerre(n)
    alphaK = 2*(0:n-1)+1;
    rad_betaK = (1:n-1);

    J = diag(alphaK) + diag(rad_betaK,1) + diag(rad_betaK,-1);

    x = eig(J)';
end