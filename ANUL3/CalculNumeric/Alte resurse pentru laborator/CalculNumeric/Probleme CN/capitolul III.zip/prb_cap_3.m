%% Capitolul III
% Problema nr. 3.71.

%%
% Sa se scrie o functie MATLAB care calculeaza polinomul de interpolare
% Lagrange al unei functii $f$ in cazul cand nodurile sunt radacinilile
% polinoamelor ortogonale lui Laguerre. Folositi metoda baricentrica.
% Testati pentru o functie puternic oscilanta si un numar mare de noduri.

clc

n = 8;
f = @(x) sin(3*x) + 2*cos(2*x);

[yi,xi] = interpNodeLaguerre(f,n,200);
plot(xi,f(xi),xi,yi)
    