%% Capitolul I
%%
% *Problema practica : Pb. 1.32*
%
%%
% Fie
% 
        % $$f(x) = exp(x) - cos(x) - x;$$

%%
% a. Reprezentati grafic f pe o vecintate a lui 0, utilizand metodele
% Analizei Numerice.


% lim f, x -> inf = inf
% lim f, x -> -inf = inf
%
% f'(x) = e^x + sin(x) - 1 => o infinitate de minime si maxime pentru x < 0
% x = linspace(-30,3,100);
% f = exp(x) + sin(x) - 1;
%plot(x,f,'-b')
%grid on


y = linspace(-30,3,100);
g = exp(y) - cos(y) - y;

% daca vrem sa avem ambele gragice pe acelasi output
% subplot(1,2,1) 
plot(y,g,'-b')
grid on

%%
% b. Reprezentati grafic f pentru 
% 
        % $$|x| < 5 * 10^(-8);$
%         
% utilizand artimetica in virgula flotanta, in simple si dubla precizie

y = linspace(-5e-8,5e-8,100);
g = exp(y) - cos(y) - y;
x1 = single(linspace(-5e-8,5e-8,100));
f1 = (exp(x1) - cos(x1) - x1);

% daca vrem sa avem ambele gragice pe acelasi output
% subplot(1,2,2)
plot(y,g,'-b',x1,f1,'-r')
grid on
legend('dubla precizie','simpla prec')
%%


