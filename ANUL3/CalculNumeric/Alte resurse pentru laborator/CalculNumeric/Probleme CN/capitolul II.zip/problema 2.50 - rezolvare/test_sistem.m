%% Capitolul II
% Problema practica: 2.50

clc
n = 10;
%%
% Construiesc matricea a (de dimensiune n) folosind comenzile 
% diag si ones 
A = diag(ones(n,1)*2) + diag(-ones(n-1,1),1) + diag(-ones(n-1,1),-1)
%%
% Construiesc matricea B prin concatenarea matricelor A (de dimensiune n)
% cu matricea unitate In
B = [A,eye(n)]

for i=1:n
    m = B(i,i);
    for j = 1:2*n
        B(i,j) = B(i,j)/m;
    end
    for j = 1:n
        if (j ~= i)
            mm = B(j,i);
            for k = 1:2*n
               B(j,k)=B(j,k) - mm * B(i,k);
            end
        end
    end
end

%%
% Prin eliminarea primelor n coloane obtinem inversa matricei A

AInv = zeros(n,n);
for i=1:n
    m=1;
    for j=n+1:2*n
       AInv(i,m)=B(i,j);
       m=m+1;
    end
end
AInv

%% Test
BInv = inv(A)

