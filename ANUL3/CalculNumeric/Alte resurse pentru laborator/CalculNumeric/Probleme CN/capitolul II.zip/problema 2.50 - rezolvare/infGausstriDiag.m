function AInv = infGausstriDiag(A)
[n,m] = size(A);

if n ~= m
    error('Matricea nu este patratica')
end
AInv = zeros(n,n);
A = [A,eye(n)]; %matricea unitate

for i = 1:n-1
     for j = i+1:n
            mij = A(j,i)/A(i,i);
            A(j,:) = A(j,:)-mij*A(i,:);
     end
end
if A(m,n) == 0
    error('Nu exista solutie unica')
end

AInv(n,:) = A(n,n+1:2*n)/A(n,n);
for i = n-1:-1:1
 AInv(i,:) = ( A(i,n+1:2*n) - A(i,i+1:n) * AInv(i+1:n,:)) / A(i,i);
end


%rezolvare caz general
% trebuie adaptata la matricea diagonala