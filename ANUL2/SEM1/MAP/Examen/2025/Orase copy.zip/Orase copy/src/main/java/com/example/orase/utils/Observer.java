package com.example.orase.utils;

public interface Observer {
    void update();
}