package com.example.orase.controller;

import com.example.orase.domain.City;
import com.example.orase.service.Service;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.List;
import java.util.Optional;

public class Controller {
    @FXML
    private ComboBox<String> departureCityComboBox;
    @FXML
    private ComboBox<String> destinationCityComboBox;
    @FXML
    private CheckBox directRoutesOnlyCheckBox;
    @FXML
    private Button searchButton;
    @FXML
    private TextArea resultTextArea;

    private Service service;

    public void setService(Service service) {
        this.service = service;
        loadCities();
    }

    private void loadCities() {
        List<String> cities = service.getAllCities();
        ObservableList<String> cityList = FXCollections.observableArrayList(cities);
        departureCityComboBox.setItems(cityList);
        destinationCityComboBox.setItems(cityList);
    }

    @FXML
    private void handleSearch() {
    String fromCityName = departureCityComboBox.getValue();
    String toCityName = destinationCityComboBox.getValue();
    boolean directOnly = directRoutesOnlyCheckBox.isSelected();

    if (fromCityName != null && toCityName != null) {
        Optional<City> fromCity = service.getCityByName(fromCityName);
        Optional<City> toCity = service.getCityByName(toCityName);

        if (fromCity.isPresent() && toCity.isPresent()) {
            String fromCityId = fromCity.get().getId();
            String toCityId = toCity.get().getId();
            List<String> routes = service.getRoutes(fromCityId, toCityId, directOnly);
            resultTextArea.setText(String.join("\n", routes));
        } else {
            resultTextArea.setText("City not found.");
        }
    } else {
        resultTextArea.setText("Please select both departure and destination cities.");
    }
}

}